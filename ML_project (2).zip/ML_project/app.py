import numpy as np
import pandas as pd
import pickle
from flask import Flask, request, jsonify, render_template
import joblib

# Create flask app
app = Flask(__name__, template_folder=r'C:\Users\Veera\Documents\ML_project\templates')

# Load your model
model = pickle.load(open('model.pkl', 'rb'))
label_encoders = joblib.load('label_encoders.pkl')
scaler = joblib.load('scaler.pkl')
pca = joblib.load('pca.pkl')

# Define the columns used for encoding (excluding the target column 'class')
categorical_columns = [
    'cap-shape', 'cap-surface', 'cap-color', 'does-bruise-or-bleed', 
    'gill-attachment', 'gill-spacing', 'gill-color', 'stem-root', 
    'stem-surface', 'stem-color', 'veil-type', 'veil-color', 
    'has-ring', 'ring-type', 'spore-print-color', 'habitat', 'season'
]

# Define default values for missing features
default_values = {
    'cap-shape': 'x', 'cap-surface': 't', 'cap-color': 'n', 'does-bruise-or-bleed': 'f',
    'gill-attachment': 'a', 'gill-spacing': 'c', 'gill-color': 'w', 'stem-root': 's',
    'stem-surface': 's', 'stem-color': 'w', 'veil-type': 'u', 'veil-color': 'w',
    'has-ring': 'f', 'ring-type': 'f', 'spore-print-color': 'k', 'habitat': 'd', 'season': 'a',
    'cap-diameter': 3.18, 'stem-height': 0, 'stem-width': 0
}

# Route the home page
@app.route('/', methods=['POST', 'GET'])
def home():
     prediction_text = ""
     if request.method == 'POST':
            form_data = request.form.to_dict()
            prediction = predict(form_data)
            if prediction == 'p':
                prediction_text = "Poisonous"
            elif prediction == 'e':
                prediction_text = "Edible"
     return render_template('mushroom.html', prediction_text=prediction_text)


# Route the predict url
@app.route('/predict', methods=['POST', 'GET'])
def predict(form_data):
    # Create a DataFrame from form data
    input_data = pd.DataFrame([form_data])
    
    # Apply label encoding to the new data
    for column in input_data.columns:
        if column in label_encoders:
            le = label_encoders[column]
            input_data[column] = le.transform(input_data[column])
    
    # Separate features, exclude 'class' if it exists
    feature_columns = input_data.columns.drop('class', errors='ignore')
    X_new = input_data[feature_columns]
    
    # Apply scaling and PCA
    X_new_scaled = scaler.transform(X_new)
    X_new_pca = pca.transform(X_new_scaled)
    
    # Make prediction
    prediction = model.predict(X_new_pca)
    predicted_class = label_encoders['class'].inverse_transform(prediction)[0]
    
    return predicted_class

# Run the application
if (__name__ == '__main__'):
    app.run(debug='True')
